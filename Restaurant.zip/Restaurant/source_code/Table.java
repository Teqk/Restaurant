package com.restaurant;

import java.util.LinkedList;
import java.util.Queue;

/**
 * The buffer class Table.
 */
public class Table {
    // the name of the course
    private String course;
    // a flag used to see if the table is empty or is not empty
    public boolean isEmpty = false;
    // synchronization object
    public final Queue<Integer> queue = new LinkedList<>();

    /**
     * the Waiter serving a course
     *
     * @param course the course to serve
     */
    public void serve(String course) {
        this.course = course;
    }

    /**
     * the course that  Customer is eating.
     *
     * @return the course
     */
    public String eat() {
        return this.course;
    }
}
