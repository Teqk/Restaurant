package com.restaurant;

import java.util.Random;

/**
 * The class representing a customer.Once the customer completes a course,
 * he/she must wait for the waiter to serve the next course.
 */
public class Customer implements Runnable {
    // must wait for between 0 and 4 seconds.
    private final static int MAX_CUSTOMER_MILLIS = 4000;

    // Table object that this Customer sits at
    private final Table table;

    // name of this Customer
    private final String customerName;

    /**
     * @param table        the table that this Customer sits at
     * @param customerName the name of this Customer
     */
    public Customer(Table table, String customerName) {
        this.table = table;
        this.customerName = customerName;
    }

    /**
     * Method to implement the actions of eating and waiting for a new course.
     */
    @Override
    public void run() {
        while (!table.isEmpty) {
            synchronized (table.queue) {
                if (table.queue.size() > 0) {
                    String course = table.eat();
                    System.out.printf("%s is eating: %s\n", customerName, course);
                    table.queue.poll();
                    table.queue.notifyAll();
                }
            }
            // Waiting for a new course.
            try {
                Thread.sleep(new Random().nextInt(MAX_CUSTOMER_MILLIS));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
//        System.out.println("Customer " + customerName + " left.");
    }
}
