package com.restaurant;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The class representing a restaurant. All waiter and customer objects are created here.
 * This restaurant has one or more waiters. Each waiter waits on one or more customers.
 * Each waiter serves each customer a three-course menu (an appetizer, a main course, and a dessert).
 */
public class Restaurant {
    private final ArrayList<Waiter> waiterList;
    private final ArrayList<Customer> customerList;


    public Restaurant() {
        waiterList = new ArrayList<>();
        customerList = new ArrayList<>();
    }

    /**
     * Program start entry.
     *
     * @param args system args
     */
    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant();
        restaurant.readFile();
        restaurant.startTask();
    }

    /**
     * Read and check the file provided by user.
     */
    private void readFile() {
        System.out.println("Enter the name of the file to test:");
        // read file path from commandline.
        Scanner sc = new Scanner(System.in);
        String fileName = sc.next();
        if (!fileName.contains(".")) {
            fileName = fileName + ".txt";
        }

        // read file.
        try {
            Scanner sc_f = new Scanner(new File(fileName));
            String num = sc_f.nextLine();

            // check the num of waiters
            if (!FileChecker.checkNum(num)) {
                System.out.printf("Error:the number of waiters (%s) is invalid.\n", num);
                System.exit(-1);
            }

            // read the next lines;
            int lineNo = 2;
            while (sc_f.hasNextLine()) {
                String line = sc_f.nextLine();
                // check the line.
                if (!FileChecker.checkLine(line)) {
                    System.out.printf("Error:line %s in file %s is invalid.\n", lineNo, fileName);
                    System.exit(-1);
                }
                this.create(line.split(" "));
                lineNo++;
            }

        } catch (FileNotFoundException e) {
            System.out.printf("Error:File %s not found.\n", fileName);
            System.exit(-1);
        }
    }

    /**
     * extract information to create customers and waiters.
     *
     * @param lineArr string list from a line of the file provided.
     */
    public void create(String[] lineArr) {
        // ignore the empty line.
        if (lineArr.length < 2) {
            return;
        }
        //System.out.println(Arrays.toString(lineArr));

        String waiterName = lineArr[0];
        int customerNum = Integer.parseInt(lineArr[1]);
        // create table
        Table[] tables = new Table[customerNum];
        for (int i = 0; i < tables.length; i++) {
            tables[i] = new Table();
        }
        // Collect information for creating waiters and customers.
        String[] customerNames = new String[customerNum];
        String[][] courses = new String[customerNum][3];
        int k = 2;
        for (int i = 0; i < customerNum; i++) {
            String str = lineArr[k];
            customerNames[i] = str;
            Customer customer_i = new Customer(tables[i], str);
            customerList.add(customer_i);
            k += 1;
            for (int j = 0; j < 3; j++) {
                courses[i][j] = lineArr[k];
                k += 1;
            }
        }
        Waiter waiter_i = new Waiter(tables, waiterName, customerNames, courses);
        waiterList.add(waiter_i);

    }

    /**
     * start all waiter and customer threads.
     */
    public void startTask() {
        for (Waiter waiter : waiterList) {
            Thread t = new Thread(waiter);
            t.start();
        }
        for (Customer customer : customerList) {
            Thread t = new Thread(customer);
            t.start();
        }
    }
}
