package com.restaurant;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Use Regular expression to check the file format.
 */
public class FileChecker {

    private static final String checkWaiterNumPattern = "[^1-9]";
    private static final String checkWaiterInfoPattern = "[^(1-9WCAMD_\\s)]";
    private static final Pattern patternNum = Pattern.compile(checkWaiterNumPattern);
    private static final Pattern patternInfo = Pattern.compile(checkWaiterInfoPattern);

    /**
     * Method to check the number of waiters.
     *
     * @param line the line that indicate the number of waiters from user-input file.
     * @return boolean. true means the file is valid.
     */
    public static boolean checkNum(String line) {
        if (line.isEmpty()) {
            return false;
        }
        Matcher m = patternNum.matcher(line);
        return !m.find();
    }

    /**
     * Method to check the content of other lines.
     *
     * @param line other line for the user-input file.
     * @return boolean. true means the file is valid.
     */
    public static boolean checkLine(String line) {
        Matcher m = patternInfo.matcher(line);
        return !m.find();
    }
}
