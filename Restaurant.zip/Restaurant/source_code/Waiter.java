package com.restaurant;

import java.util.Objects;
import java.util.Random;


/**
 * The class representing a waiter.The waiter must serve only one course at a time, i.e.,
 * the waiter must wait for the customer to complete one course before serving another course.
 */
public class Waiter implements Runnable {
    // must wait for between 0 and 4 seconds.
    private final static int MAX_WAITER_MILLIS = 4000;

    // number of courses is exactly three.
    private final static int N_COURSES = 3;

    // array of Table objects this Waiter waits on
    private final Table[] tables;

    // name of this Waiter
    private final String waiterName;

    // names of Customers served by Waiter
    private final String[] customerNames;

    // multi-dimensional array of courses for each Customer of this Waiter.
    // (courses[i][j] has the j-th course for the i-th Customer of this Waiter)
    private final String[][] courses;

    /**
     * Instantiates a new Waiter.
     *
     * @param tables        array of Table objects this Waiter waits on
     * @param waiterName    name of this Waiter
     * @param customerNames names of Customers served by Waiter
     * @param courses       multi-dimensional array of courses for each Customer of this Waiter.
     */
    public Waiter(Table[] tables, String waiterName, String[] customerNames, String[][] courses) {
        this.tables = tables;
        this.waiterName = waiterName;
        this.customerNames = customerNames;
        this.courses = courses;
    }

    /**
     * Method to implement the actions of serving and waiting for a customer to ask for a new course.
     */
    @Override
    public void run() {
        int emptyTableCount = 0;
        while (emptyTableCount < tables.length) {
            for (int i = 0; i < tables.length; i++) {
                if (tables[i].isEmpty) {
                    continue;
                }
                synchronized (tables[i].queue) {
                    if (tables[i].queue.size() == 0) {
                        String course = chooseCourse(i);
                        if (course.equals("")) {
                            // The customer has finished his meal.exit the customer thread.
                            tables[i].isEmpty = true;
                            emptyTableCount += 1;
                        } else {
                            tables[i].serve(course);
                            System.out.printf("%s serves %s %s\n", waiterName, this.customerNames[i], course);
                            tables[i].queue.offer(0);
                            tables[i].queue.notifyAll();
                        }
                    }
                }
                // All customer is eating,waiting for a call.
                try {
                    Thread.sleep(new Random().nextInt(MAX_WAITER_MILLIS));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     * choose a course to serve for the customer.
     *
     * @param customerIndex index of customer.
     * @return course name.
     */
    private String chooseCourse(int customerIndex) {
        for (int i = 0; i < N_COURSES; i++) {
            if (!Objects.equals(courses[customerIndex][i], "*")) {
                String courseName = courses[customerIndex][i];
                courses[customerIndex][i] = "*";
                return courseName;
            }
        }
        // The customer has finished all courses.
        return "";
    }
}
